import React, { useState } from "react"
// import React, { useEffect, useState } from "react"
import axios from "axios"
import { useNavigate, Link } from "react-router-dom"
import signUpCSS from "./signUp.module.css";

function Login() {

    const history = useNavigate();

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    async function submit(e) {
        e.preventDefault();

        try {
            await axios.post("http://localhost:8000/SignUp", { email, password })
                .then(res => {
                    if (res.data === "exists") {
                        alert("User already exists")
                    
                    }
                    else if (res.data === "notExists") {
                        history("/", { state: { id: email } })
                        alert("You are successfully registered! \nPlease login with credentials you provided")
                    }
                })
                .catch(e => {
                    alert("Wrong details")
                    console.log(e)
                })
        } catch (e) {
            console.log(e)
        }
    }

    return (
        <div className={signUpCSS.signALL}>
        <div className={signUpCSS.box}>
            <span class={signUpCSS.borderLine}></span>
            <form action="POST">
                <h2>SignUp</h2>
                <div className={signUpCSS.inputBox}>
                    <input type="email" onChange={(e) => { setEmail(e.target.value) }} required name="" id="" />
                    <span>Username</span>
                    <i></i>
                </div>
                <div className={signUpCSS.inputBox}>
                    <input type="password" onChange={(e) => { setPassword(e.target.value) }} required name="" id="" />
                    <span>Password</span>
                    <i></i>
                </div>
                <div className={signUpCSS.links}>
                <a href="https://www.google.com/search?q=google&oq=google&aqs=chrome..69i57j46i131i199i433i465i512j69i60j69i65l3j69i60l2.3651j0j7&sourceid=chrome&ie=UTF-8">SignUp with Google</a>
                    <Link to="/">Login Page</Link>
                </div>
                <input type="submit" value="Submit" onClick={submit} />
            </form>            
        </div>
        </div>
    )
}

export default Login