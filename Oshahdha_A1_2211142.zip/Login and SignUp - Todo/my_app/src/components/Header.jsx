import React from 'react';
import appCSS from '../App.module.css';

const Header = () => {
  return (
    <div className={appCSS.header}>
        <h1>Todo-List</h1>
    </div>
  )
}

export default Header