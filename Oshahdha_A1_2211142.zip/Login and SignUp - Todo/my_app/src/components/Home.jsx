import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import Header from './Header';
import Form from './Form';
import TodoList from './TodoList';
import appCSS from '../App.module.css';

function Home() {

  const initialState = JSON.parse(localStorage.getItem("todos")) || [];
  const [input, setInput] = useState("");
  const [todos, setTodos] = useState(initialState);
  const [editTodo, setEditTodo] = useState(null);

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(todos));
  }, [todos]);

  const location = useLocation();
  const user = location.state?.user || "User";

  const handleSignOut = () => {
    // clear user session and redirect to login page
    localStorage.removeItem('user');
    window.location.href = 'http://localhost:3000/';
  }

  return (
    <div className={appCSS.container}>
      <nav className={appCSS.navbar}>
        <div className={appCSS.navbarTitle}>Todo App</div>
        <div className={appCSS.navbarLinks}>
          <Link to="./" className={appCSS.navbarLink}>
            Home
          </Link>
          <div className={appCSS.navbarLink}>
            Logged in as {user}
          </div>
          <button className={appCSS.logoutButton} onClick={handleSignOut}>
            Logout
          </button>
        </div>
      </nav>
      <div className={appCSS.app_wrapper}>
        <div>
          <Header />
        </div>
        <div>
          <Form 
            input={input}
            setInput={setInput}
            todos={todos}
            setTodos={setTodos}
            editTodo={editTodo}
            setEditTodo={setEditTodo}
          />
        </div>
        <div>
          <TodoList 
            todos={todos} 
            setTodos={setTodos} 
            setEditTodo={setEditTodo}
          />
        </div>
      </div>
    </div>
  );
}

export default Home;
