import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";
import loginCSS from "./login.module.css";

function Login() {
  const history = useNavigate();
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  

  async function submit(e) {
    e.preventDefault();

    try {
      const response = await axios.post("http://localhost:8000/", {
        email,
        password,
      });
      const { data } = response;
      if (data === "exists") {
        const checkPassword = await axios.post(
          "http://localhost:8000/checkPassword",
          { email, password }
        );
        if (checkPassword.data === "match") {
            history("/home", { state: { email, name: data.name } });
        } else {
          alert("Wrong password");
        }
      } else if (data === "notExists") {
        alert("User have not signed up");
      }
    } catch (e) {
      console.log(e);
    }
  }

  return (
    <div className={loginCSS.loginALL}>
      <div className={loginCSS.loginALL2}>
        <div className={loginCSS.box}>
          <span className={loginCSS.borderLine}></span>
          <form action="POST">
            <h2>Login</h2>
            <div className={loginCSS.inputBox}>
              <input
                type="email"
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
                name="email"
                id="email"
              />
              <span>Email</span>
              <i></i>
            </div>
            <div className={loginCSS.inputBox}>
              <input
                type="password"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                name="password"
                id="password"
              />
              <span>Password</span>
              <i></i>
            </div>
            <div className={loginCSS.links}>
              <a href="http://localhost:3000/forgot-password">Forget Password</a>
              <Link to="/signup">SignUp Page</Link>
            </div>

            <input type="submit" value="Login" onClick={submit} />
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
