import React from 'react';
import appCSS from '../App.module.css';

const TodoList = ({todos, setTodos, setEditTodo}) => {

    const handleComplete = (todo) =>{
        setTodos(
            todos.map((item) => {
                if(item.id === todo.id) {
                    return {...item, completed: !item.completed}
                }
                return item;
            })
        )
    }

    const handleEdit = ({id}) => {
        const findTodo = todos.find((todo) => todo.id === id);
        setEditTodo(findTodo);
    }

    const handleDelete = ({id}) => {
        setTodos(todos.filter((todo) => todo.id !== id));
    };

  return (
    <div>
        {todos.map((todo) => (
            <li className={appCSS.list_item} key={todo.id}>
                <input type="text" 
                value={todo.title} 
                className={`${appCSS.list} ${todo.completed ? appCSS.complete : ""}`} 
                onChange={(event) => event.preventDefault()} 
                />
                <div>
                <button className={`${appCSS.button_complete} ${appCSS.task_button}`} onClick={() => handleComplete(todo)}>
                        <i className="fa fa-check-circle"></i>
                    </button>
                    <button className={`${appCSS.button_edit} ${appCSS.task_button}`} onClick={() => handleEdit(todo)} >
                        <i className='fa fa-edit'></i>
                    </button>
                    <button className={`${appCSS.button_delete} ${appCSS.task_button}`} onClick={() => handleDelete(todo)} >
                        <i className='fa fa-trash'></i>
                    </button>
                </div>
            </li>
        )

        )}
    </div>
  )
}

export default TodoList